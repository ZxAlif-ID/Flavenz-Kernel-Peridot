#!/system/bin/sh
# service.sh — Flavenz Performance Tuner
# Runs at late-start service (non-blocking), post-Android framework
# KernelSU-Next lifecycle: service.sh runs after overlays mount

MODDIR="${0%/*}"
LOG=/data/local/tmp/flavenz_perf.log
TS=$(date "+%Y-%m-%d %H:%M:%S")
log() { echo "[$TS] $1" >> "$LOG"; }

log "=== Flavenz Performance Tuner v1.0.0 ==="
log "Running from: $MODDIR"

# Tunggu boot complete
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
sleep 5

# === [1] uclamp — prime core (X4) hint untuk foreground tasks ===
echo 50  > /dev/cpuctl/top-app/cpu.uclamp.min 2>/dev/null \
  && log "[OK] uclamp top-app.min=50" || log "[WARN] uclamp top-app.min failed"
echo 1   > /dev/cpuctl/top-app/cpu.uclamp.latency_sensitive 2>/dev/null \
  && log "[OK] uclamp top-app.latency_sensitive=1" || log "[WARN] uclamp latency failed"
echo 50  > /dev/cpuctl/foreground/cpu.uclamp.min 2>/dev/null \
  && log "[OK] uclamp foreground.min=50" || log "[WARN] uclamp fg failed"
echo 1   > /dev/cpuctl/foreground/cpu.uclamp.latency_sensitive 2>/dev/null || true
echo 0   > /dev/cpuctl/background/cpu.uclamp.min 2>/dev/null || true
echo 0   > /dev/cpuctl/background/cpu.uclamp.latency_sensitive 2>/dev/null || true

# === [2] Unlock X4 Prime Core ke OPP max (1324800 → 2918400 kHz) ===
echo 2918400 > /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq 2>/dev/null \
  && log "[OK] X4 max_freq=2918400 kHz" || log "[WARN] X4 freq unlock failed"

# === [3] GPU unlock ke 1100 MHz ===
echo 1100000000 > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq 2>/dev/null \
  && log "[OK] GPU max_freq=1100MHz" || log "[WARN] GPU freq unlock failed"

# === [4] Thermal — gaming mode ===
echo 3 > /sys/class/thermal/thermal_message/sconfig 2>/dev/null \
  && log "[OK] thermal sconfig=3 (gaming)" || log "[WARN] thermal sconfig failed"

# === [5] Memory tuning ===
echo 60  > /proc/sys/vm/swappiness 2>/dev/null && log "[OK] swappiness=60" || true
echo 80  > /proc/sys/vm/vfs_cache_pressure 2>/dev/null || true
echo 4   > /proc/sys/vm/page-cluster 2>/dev/null || true

# === [6] zram → zstd ===
ALGO=$(cat /sys/block/zram0/comp_algorithm 2>/dev/null || echo "")
if echo "$ALGO" | grep -q "\[zstd\]"; then
    log "[OK] zram: zstd already active"
elif echo "$ALGO" | grep -q "zstd"; then
    # Available but not selected
    swapoff /dev/block/zram0 2>/dev/null || true
    sleep 1
    echo 1             > /sys/block/zram0/reset
    echo zstd          > /sys/block/zram0/comp_algorithm
    echo 12884901888   > /sys/block/zram0/disksize
    mkswap /dev/block/zram0
    swapon /dev/block/zram0 -p -2
    log "[OK] zram: switched to zstd"
else
    log "[INFO] zram: algo=$ALGO, zstd not available"
fi

# === DONE — write state summary ===
log "--- FINAL STATE ---"
log "X4 max_freq   : $(cat /sys/devices/system/cpu/cpufreq/policy7/scaling_max_freq 2>/dev/null)"
log "GPU max_freq  : $(cat /sys/class/kgsl/kgsl-3d0/devfreq/max_freq 2>/dev/null)"
log "uclamp min    : $(cat /dev/cpuctl/top-app/cpu.uclamp.min 2>/dev/null)"
log "latency_sens  : $(cat /dev/cpuctl/top-app/cpu.uclamp.latency_sensitive 2>/dev/null)"
log "swappiness    : $(cat /proc/sys/vm/swappiness)"
log "zram algo     : $(cat /sys/block/zram0/comp_algorithm 2>/dev/null)"
log "thermal sconf : $(cat /sys/class/thermal/thermal_message/sconfig 2>/dev/null)"
log "=== DONE ==="
