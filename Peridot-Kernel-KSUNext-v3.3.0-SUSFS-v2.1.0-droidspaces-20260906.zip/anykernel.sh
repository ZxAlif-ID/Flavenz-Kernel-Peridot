# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
properties() { '
kernel.string=Peridot Kernel (Droidspaces) by ZxAlif-ID
do.devicecheck=1
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=peridot
device.name2=peridot_global
device.name3=
device.name4=
device.name5=
supported.versions=
supported.patchlevels=
'; } # end properties

## AnyKernel install
# boot shell variables
block=/dev/block/by-name/boot;
is_slot_device=1;
ramdisk_compression=auto;
patch_vbmeta_flag=auto;

# import functions/variables and setup patching (DO NOT REMOVE)
. tools/ak3-core.sh;

split_boot;
flash_boot;
